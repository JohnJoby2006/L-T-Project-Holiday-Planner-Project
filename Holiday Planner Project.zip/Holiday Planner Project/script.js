// Select Destination
function selectDestination(destination) {
  alert("You selected: " + destination);

  let activityList = document.getElementById("activityList");
  activityList.innerHTML = "";

  let activities = {
    "Beach": ["Swimming", "Surfing", "Beach Volleyball"],
    "Mountains": ["Hiking", "Camping", "Rock Climbing"],
    "City": ["Museum Visit", "Shopping", "Nightlife"]
  };

  activities[destination].forEach(activity => {
    let li = document.createElement("li");
    li.textContent = activity;
    li.classList.add("list-group-item");
    activityList.appendChild(li);
  });
}

// Save Itinerary
function saveItinerary() {
  let input = document.getElementById("itineraryInput").value;
  document.getElementById("savedItinerary").innerHTML = "<b>Your Itinerary:</b><br>" + input;
}

// Budget Tracker
function trackBudget() {
  let budget = document.getElementById("budgetInput").value;
  document.getElementById("budgetOutput").textContent = "Estimated Budget: ₹" + budget;
}
